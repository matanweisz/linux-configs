import { Gio, GLib, GObject } from "./shared.js";
import Gdk from "gi://Gdk";
import Gtk from "gi://Gtk";
import Adw from "gi://Adw";
export {
  Adw,
  GLib,
  GObject,
  Gdk,
  Gio,
  Gtk
};
